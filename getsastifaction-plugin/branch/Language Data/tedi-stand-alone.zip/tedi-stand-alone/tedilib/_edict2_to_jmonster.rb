############################################
#  TEdi (Tanaka Corpus / Edict2 Importer)
#   --- Export to jmonster (SQLite) ---
############################################


####################################################################
# Parameters: data = Hash of edict2 data
def jmonster_data_import(data)

  ja_sql_insert_header = "INSERT INTO cards_ja (guid,headword,alt_headword,reading,meaning,tags) VALUES "
  en_sql_insert_header = "INSERT INTO cards_en (guid,headword,alt_headword,reading,meaning,tags) VALUES "

  loop_count = 0
  sql_line_count = 0
  sql_line_total_count = 0
  buffered_lines = ""
  ja_master_sql_data = []
  en_master_sql_data = []
  ja_sql_arr = []
  en_sql_arr = []

  data.each do |headword,entry|
    # NB: entry[:data][:ptag, :original, :antonyms, :usages, :other_headwords]
    loop_count+=1
    sql_line_count+=1
    readings_string = ""
    descriptions_arr = []
    tags_arr = []
    tags = ""

    alt_english_text = ""
    curr_english_text = ""

    entry[:usages].each do |usage|
      readings_string = usage[:readings] if readings_string.gsub(@regexes[:tag_like], "") == ""
      tags_arr << usage[:pos_tags].split(',') if usage[:pos_tags].length > 0
      tags_arr << usage[:lang_tags].split(',') if usage[:lang_tags].length > 0
      descriptions_arr << usage[:description].strip.gsub(@regexes[:leading_trailing_slashes], "").strip.gsub("'" , '\'\'')
    end

    if !readings_string.empty?
      if tags_arr.size > 0
        tags_arr = tags_arr.flatten.uniq
        has_ptag = !tags_arr.index("P").nil?
        tags_arr.delete("P")
      else
        has_ptag = false
      end
      tags = tags_arr.join(",") if tags_arr.size > 0
      descriptions_string = descriptions_arr.join("; ").gsub('  ', ' ') 
      descriptions_string_no_tags = descriptions_string
      descriptions_string = descriptions_string + (tags.length > 0 ? " (#{tags})" : "")
      ja_headword = headword.gsub(@regexes[:tag_like], "").strip

      en_tmp = descriptions_string_no_tags.strip
      en_tmp = en_tmp.match(@regexes[:first_english_token])[0] if en_tmp.length > 25

      en_headword = en_tmp.to_s[0,1].capitalize + en_tmp[1, en_tmp.length]
      en_headword.strip!

      # NB: this block will only pass (P) tag entries
      if has_ptag
        # debug
        ja_sql_arr << ja_sql_insert_header + " ('#{ja_headword.to_s}__#{readings_string}', '#{ja_headword.to_s}','#{entry[:other_headwords]}','#{readings_string}','#{descriptions_string}', '#{tags}');"
        en_sql_arr << en_sql_insert_header + " ('#{ja_headword.to_s}__#{readings_string}', '#{en_headword.to_s}','#{descriptions_string}','#{readings_string}','#{ja_headword}', '#{tags}');"
      end
    
      if sql_line_count == @options[:import_page_size] or loop_count == data.length
        ja_master_sql_data << ja_sql_arr.join("\n").to_s + "\n\n"
        en_master_sql_data << en_sql_arr.join("\n").to_s
        puts ">>>  #{loop_count} -- Just prepared  #{sql_line_count} JE & EJ Vocab entries at #{Time.now})" #unless @options[:silent]
        sql_line_count = 0
        ja_sql_arr = []
        en_sql_arr = []
      end
    end

  end

  File.open("jmonster_vocab.sql", 'w') { |f| f.write(ja_master_sql_data.join("\n\n")) }
  File.open("jmonster_vocab.sql", 'a') { |f| f.write(en_master_sql_data.join("\n\n")) }

end