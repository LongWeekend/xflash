#----------------------------------------------------------------------------#
#  JMONSTER NameSpace
#----------------------------------------------------------------------------#
namespace :jmonster do

  desc "EDICT2 Importer Task for JMonster, ACCEPTS src={source file path} | from={start line} | to={max lines to process}"
  task :import => :environment do
    load_library
    results = process_edict("extract", get_cli_start_point, get_cli_break_point)
    jmonster_data_import(results[:data])

    unless @options[:silent]
      puts "---------------------------------------------------" unless results[:data].nil? or results[:count].nil?
      puts "new headwords: " + results[:data].length.to_s unless results[:data].nil?
      puts "new usages: " + results[:count].to_s unless results[:count].nil?
    end
  end

  desc "Database import junk script"
  task :addtags => :environment do

    ActiveRecord::Base.establish_connection (
       :adapter  => "mysql",
       :database => "lwe_import",
       :port     => 3306,
       :host     => "localhost",
       :encoding => "utf8",
       :username => "root",
       :password => ""
     )
    @cn = ActiveRecord::Base.connection()

    tags = @cn.execute("SELECT id, source_name, source FROM tags ORDER BY id")
    tag_by_name_arr = {}

    tickcount("Caching Tags") do
      tags.each do |id,name,source|
        tag_by_name_arr[name] = { :id => id, :source => source }
      end
    end
    
    data_en = nil
    ###data_ja = nil

    tickcount("Selecting Cards") do
      ## 'cards_ja' is derived from 'cards_en', so we only map tags to 'cards_en'
      data_en = @cn.execute("SELECT card_id, tags FROM cards_en")
      ###data_ja = @cn.execute("SELECT card_id, tags FROM cards_ja")
    end

    tickcount("Looping n Inserting") do
      data_en.each do |card_id, tags|
        tags.split(',').each do |tag|
          curr_tag_id = tag_by_name_arr[tag.strip][:id]
          debugger if curr_tag_id.nil? or tag.empty?
          @cn.insert("INSERT INTO card_tag_link (tag_id, card_id) values (#{curr_tag_id}, #{card_id})")
        end
      end
    end

  end

end
#----------------------------------------------------------------------------#
